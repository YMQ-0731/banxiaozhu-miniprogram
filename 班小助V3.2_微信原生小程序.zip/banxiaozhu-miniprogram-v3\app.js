const mock = require('./utils/mock.js');
const auth = require('./utils/auth.js');

App({
  globalData: {
    // ===== 登录状态（仅内存，关闭小程序即重置）=====
    isLogin: false,
    userRole: 'visitor', // visitor未登录 / student普通学生 / leader工作人员
    userName: '',
    userId: '',
    userPhone: '',
    // ===== 业务模拟数据 =====
    todoList: [],
    taskList: [],
    msgList: [],
    noticeList: [],
    // 页面间临时导航参数：消息页默认子标签
    messageTab: 'notice'
  },

  onLaunch() {
    this._studentSnapshot = null;
    this.resetDemoData();
  },

  /** 重新载入初始演示数据（不动登录态） */
  resetDemoData() {
    const data = mock.createSeedData();
    this.globalData.todoList = data.todoList;
    this.globalData.taskList = data.taskList;
    this.globalData.msgList = data.msgList;
    this.globalData.noticeList = data.noticeList;
    this.globalData.messageTab = 'notice';
  },

  /**
   * 本地模拟登录
   * @returns {{ok:boolean,message?:string,role?:string}}
   */
  login(profile) {
    const name = (profile.name || '').trim();
    const userId = (profile.userId || '').trim();
    const userPhone = (profile.userPhone || '').trim();

    if (!name || !/^\d+$/.test(userId) || !/^\d{11}$/.test(userPhone)) {
      return { ok: false, message: '请填写正确的姓名、学号、11位手机号' };
    }

    const isLeader =
      name === auth.STAFF_DEMO.name &&
      userId === auth.STAFF_DEMO.userId &&
      userPhone === auth.STAFF_DEMO.userPhone;

    if (isLeader) {
      this._studentSnapshot = null;
    }

    this.globalData.isLogin = true;
    this.globalData.userRole = isLeader ? 'leader' : 'student';
    this.globalData.userName = name;
    this.globalData.userId = userId;
    this.globalData.userPhone = userPhone;

    return { ok: true, role: this.globalData.userRole };
  },

  /**
   * 学生 → 工作人员：必须验证班干部账号与密码。
   * 账号：2023010101 / 密码：banzhu123（仅演示）
   */
  switchToLeader(account, password) {
    const acc = (account || '').trim();
    const pwd = (password || '').trim();

    if (acc !== auth.STAFF_DEMO.account || pwd !== auth.STAFF_DEMO.password) {
      return { ok: false, message: '班干部账号或密码错误' };
    }

    if (this.globalData.userRole !== 'leader') {
      this._studentSnapshot = {
        name: this.globalData.userName,
        userId: this.globalData.userId,
        userPhone: this.globalData.userPhone
      };
    }

    this.globalData.isLogin = true;
    this.globalData.userRole = 'leader';
    this.globalData.userName = auth.STAFF_DEMO.name;
    this.globalData.userId = auth.STAFF_DEMO.userId;
    this.globalData.userPhone = auth.STAFF_DEMO.userPhone;

    return { ok: true, role: 'leader' };
  },

  /**
   * 工作人员 → 学生：优先恢复切换前保存的学生身份，
   * 若直接以工作人员身份登录，则使用内置学生演示身份。
   */
  switchToStudent() {
    if (this.globalData.userRole === 'student') {
      return { ok: true, role: 'student', unchanged: true };
    }

    const snapshot = this._studentSnapshot;
    const profile =
      snapshot && snapshot.name
        ? snapshot
        : {
            name: auth.STUDENT_DEMO.name,
            userId: auth.STUDENT_DEMO.userId,
            userPhone: auth.STUDENT_DEMO.userPhone
          };

    this.globalData.isLogin = true;
    this.globalData.userRole = 'student';
    this.globalData.userName = profile.name;
    this.globalData.userId = profile.userId;
    this.globalData.userPhone = profile.userPhone;

    this._studentSnapshot = null;
    return { ok: true, role: 'student' };
  },

  /** 退出登录：只清空用户信息，清空所有身份字段 */
  logout() {
    this.globalData.isLogin = false;
    this.globalData.userRole = 'visitor';
    this.globalData.userName = '';
    this.globalData.userId = '';
    this.globalData.userPhone = '';
    this.globalData.messageTab = 'notice';
    this._studentSnapshot = null;
  },

  getRoleText() {
    const role = this.globalData.userRole;
    if (role === 'leader') return '工作人员';
    if (role === 'student') return '普通学生';
    return '访客';
  },

  getTodoStats() {
    const list = this.globalData.todoList;
    const done = list.filter(function (item) { return item.done; }).length;
    return {
      total: list.length,
      done: done,
      pending: list.length - done,
      percent: list.length ? Math.round((done / list.length) * 100) : 0
    };
  },

  getTaskStats() {
    const list = this.globalData.taskList;
    const done = list.filter(function (item) { return item.statusKey === 'done'; }).length;
    const ongoing = list.filter(function (item) { return item.statusKey === 'ongoing'; }).length;
    const pending = list.length - done - ongoing;
    return {
      total: list.length,
      done: done,
      ongoing: ongoing,
      pending: pending,
      percent: list.length ? Math.round((done / list.length) * 100) : 0
    };
  },

  getUnreadCount() {
    if (!this.globalData.isLogin) return 0;
    return this.globalData.msgList.filter(function (item) { return !item.read; }).length;
  },

  /** 标记待办完成，并写入一条本地状态消息供驾驶舱时间轴使用 */
  completeTodo(id) {
    const todo = this.globalData.todoList.find(function (item) { return item.id === id; });
    if (!todo || todo.done) return false;
    todo.done = true;
    todo.doneTime = mock.nowTime();
    return true;
  },

  markMessageRead(id) {
    const msg = this.globalData.msgList.find(function (item) { return item.id === id; });
    if (msg && !msg.read) {
      msg.read = true;
      return true;
    }
    return false;
  },

  markAllMessagesRead() {
    this.globalData.msgList.forEach(function (item) { item.read = true; });
  },

  /** 发布公告：消息页读取同一个 noticeList，天然实时同步 */
  addNotice(payload) {
    const notice = {
      id: 'N' + Date.now(),
      title: payload.title,
      content: payload.content,
      time: '刚刚',
      author: payload.author || this.globalData.userName || '班干部',
      pinned: !!payload.pinned,
      tag: payload.tag || '班级公告',
      isNew: true
    };
    this.globalData.noticeList.unshift(notice);
    return notice;
  },

  /** 模拟执行后写入驾驶舱任务 */
  addTask(payload) {
    const task = {
      id: 'T' + Date.now(),
      title: payload.title,
      type: payload.type || '班级事务',
      owner: this.globalData.userName || '班干部',
      deadline: payload.deadline || '本周内',
      status: '进行中',
      statusKey: 'ongoing',
      progress: 10,
      joined: 0,
      target: 36,
      desc: payload.desc || '由班小助发起事务页面模拟创建。',
      isNew: true
    };
    this.globalData.taskList.unshift(task);
    return task;
  },

  addMessage(payload) {
    const msg = {
      id: 'M' + Date.now(),
      type: payload.type || 'status',
      typeText: payload.typeText || '状态变更',
      title: payload.title,
      content: payload.content,
      time: '刚刚',
      read: false
    };
    this.globalData.msgList.unshift(msg);
    return msg;
  }
});
