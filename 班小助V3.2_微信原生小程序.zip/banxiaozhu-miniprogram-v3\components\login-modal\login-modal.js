const app = getApp();
const auth = require('../../utils/auth.js');

Component({
  properties: {
    show: {
      type: Boolean,
      value: false
    },
    closable: {
      type: Boolean,
      value: true
    }
  },

  data: {
    form: {
      name: '',
      userId: '',
      userPhone: ''
    }
  },

  observers: {
    show(value) {
      if (value) {
        this.setData({ form: { name: '', userId: '', userPhone: '' } });
      }
    }
  },

  methods: {
    stop() {},

    onMaskTap() {
      if (this.properties.closable) {
        this.triggerEvent('cancel');
      }
    },

    onClose() {
      if (this.properties.closable) {
        this.triggerEvent('cancel');
      }
    },

    onInput(e) {
      const field = e.currentTarget.dataset.field;
      const value = e.detail.value;
      this.setData({ ['form.' + field]: value });
    },

    fillDemo() {
      this.setData({
        form: {
          name: auth.STAFF_DEMO.name,
          userId: auth.STAFF_DEMO.userId,
          userPhone: auth.STAFF_DEMO.userPhone
        }
      });
      wx.showToast({ title: '已填入演示账号', icon: 'none', duration: 1200 });
    },

    submit() {
      const form = this.data.form;
      const result = app.login({
        name: form.name,
        userId: form.userId,
        userPhone: form.userPhone
      });

      if (!result.ok) {
        wx.showToast({
          title: result.message,
          icon: 'none',
          duration: 2200
        });
        return;
      }

      this.setData({ form: { name: '', userId: '', userPhone: '' } });
      wx.showToast({
        title: result.role === 'leader' ? '工作人员登录成功' : '登录成功',
        icon: 'none',
        duration: 1400
      });
      this.triggerEvent('success', { role: result.role });
    }
  }
});
