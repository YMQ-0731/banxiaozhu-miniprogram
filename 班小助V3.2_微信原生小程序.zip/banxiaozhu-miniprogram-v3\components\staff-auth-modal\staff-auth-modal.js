const app = getApp();
const auth = require('../../utils/auth.js');

Component({
  properties: {
    show: {
      type: Boolean,
      value: false
    }
  },

  data: {
    form: {
      account: '',
      password: ''
    },
    demoAccount: auth.STAFF_DEMO.account,
    demoPassword: auth.STAFF_DEMO.password
  },

  observers: {
    show(value) {
      if (value) {
        this.setData({ form: { account: '', password: '' } });
      }
    }
  },

  methods: {
    stop() {},

    onMaskTap() {
      this.triggerEvent('cancel');
    },

    onClose() {
      this.triggerEvent('cancel');
    },

    onInput(e) {
      const field = e.currentTarget.dataset.field;
      this.setData({ ['form.' + field]: e.detail.value });
    },

    fillDemo() {
      this.setData({
        form: {
          account: auth.STAFF_DEMO.account,
          password: auth.STAFF_DEMO.password
        }
      });
      wx.showToast({ title: '已填入班干部演示账号', icon: 'none', duration: 1200 });
    },

    submit() {
      const account = (this.data.form.account || '').trim();
      const password = (this.data.form.password || '').trim();
      if (!account || !password) {
        wx.showToast({ title: '请输入班干部账号和密码', icon: 'none' });
        return;
      }

      const result = app.switchToLeader(account, password);
      if (!result.ok) {
        wx.showToast({ title: result.message, icon: 'none', duration: 1800 });
        return;
      }

      this.setData({ form: { account: '', password: '' } });
      wx.showToast({ title: '已切换至工作人员端', icon: 'none', duration: 1500 });
      this.triggerEvent('success', { role: 'leader' });
    }
  }
});
