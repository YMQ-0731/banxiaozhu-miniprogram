const TAB_ROUTES = [
  '/pages/index/index',
  '/pages/message/message',
  '/pages/dashboard/dashboard',
  '/pages/mine/mine'
];

Component({
  data: {
    selected: 0,
    unread: 0,
    isLeader: false,
    glassSolid: false
  },

  lifetimes: {
    attached() {
      this.setData({ selected: this.data.selected || 0 });
      this.refreshRoleAndBadge();
    }
  },

  pageLifetimes: {
    show() {
      this.refreshRoleAndBadge();
    }
  },

  methods: {
    refreshRoleAndBadge() {
      const app = getApp();
      this.setData({
        isLeader: app.globalData.userRole === 'leader',
        unread: app.getUnreadCount ? app.getUnreadCount() : 0
      });
    },

    onTabTap(e) {
      const index = Number(e.currentTarget.dataset.index);
      if (index === this.data.selected) return;
      this.setData({ selected: index });
      wx.switchTab({ url: TAB_ROUTES[index] });
    },

    onCenter() {
      const app = getApp();
      if (!app.globalData.isLogin) {
        wx.showToast({ title: '请先完成登录', icon: 'none', duration: 1600 });
        return;
      }
      if (app.globalData.userRole !== 'leader') {
        wx.showToast({ title: '仅工作人员可使用该功能', icon: 'none', duration: 1800 });
        return;
      }
      wx.navigateTo({ url: '/pages/publishTask/publishTask' });
    }
  }
});
