const app = getApp();
const mock = require('../../utils/mock.js');

function buildReply(prompt) {
  const text = prompt || '';
  const taskStats = app.getTaskStats();
  const todoStats = app.getTodoStats();
  const gd = app.globalData;
  const firstActive = gd.taskList.find(function (task) { return task.statusKey !== 'done'; });

  if (/汇总|统计|本周|驾驶舱|数据/.test(text)) {
    return (
      '我帮你汇总了本次运行中的班级数据：\n' +
      '· 班级事务：' +
      taskStats.total +
      ' 项，已完成 ' +
      taskStats.done +
      ' 项，完成率 ' +
      taskStats.percent +
      '%\n' +
      '· 我的待办：' +
      todoStats.total +
      ' 项，已完成 ' +
      todoStats.done +
      ' 项\n' +
      '· 未读消息：' +
      app.getUnreadCount() +
      ' 条\n\n' +
      '建议先处理临近截止的待办，再关注回执缺口较大的事务。'
    );
  }

  if (/拆解|步骤|团日|班会|活动|方案/.test(text)) {
    return (
      '可以按「目标 — 分工 — 通知 — 归档」四步拆解：\n' +
      '1. 明确交付物：签到表、回执、照片或材料清单。\n' +
      '2. 指定负责人：通知、统计、现场记录分别到人。\n' +
      '3. 发布通知并设置截止时间，提前 1 天生成催办。\n' +
      '4. 活动结束当天完成材料归档，自动形成台账。\n\n' +
      (firstActive
        ? '当前可优先参考「' + firstActive.title + '」的结构。'
        : '当前没有进行中的事务，等工作人员通过班小助智能体发起后会同步显示。')
    );
  }

  if (/催办|提醒|通知|文案/.test(text)) {
    return (
      '给你一版温和催办文案：\n' +
      '“各位同学好～关于本周班级事务，还有部分同学未完成，麻烦大家在今晚 20:00 前处理一下，完成后回复「收到」即可，感谢配合！”\n\n' +
      '如果需要更正式的语气，可以让工作人员在班小助智能体中切换为严肃催办。'
    );
  }

  if (/安全|反诈|教育|答题/.test(text)) {
    return (
      '安全提醒可以这样写：\n' +
      '“请全体同学于本周内完成校园安全教育线上答题，并提高反诈意识：不轻信陌生链接、不随意转账、不泄露验证码。完成后请在班级接龙中回复。”\n\n' +
      '本条回复由本地规则生成，不调用大模型。'
    );
  }

  if (/待办|完成|任务/.test(text)) {
    const pending = gd.todoList.filter(function (item) { return !item.done; });
    const isLeader = gd.userRole === 'leader';
    if (!pending.length) {
      return isLeader
        ? '你的个人待办已经全部完成，可以去驾驶舱看看班级整体事务进度。'
        : '你的个人待办已经全部完成，今天可以轻松一点。';
    }
    return (
      '你当前还有 ' +
      pending.length +
      ' 项待办：\n' +
      pending
        .slice(0, 3)
        .map(function (item, index) {
          return index + 1 + '. ' + item.title + '（' + item.due + '）';
        })
        .join('\n') +
      '\n\n完成后记得在首页点击圆形勾选，完成数据会同步到班级统计。'
    );
  }

  if (/登录|账号|身份|班干部/.test(text)) {
    return (
      '本次演示无需密码。工作人员账号为：班长张三 / 2023010101 / 13800138000；普通学生填写任意有效姓名、纯数字学号和 11 位手机号即可。\n' +
      '全部身份信息只保存在内存中，关闭小程序后自动清空。'
    );
  }

  if (/你好|您好|hi|hello|嗨/.test(text.toLowerCase())) {
    return '你好呀，我是班小助。可以帮你汇总班级事务、拆解活动步骤、生成通知和催办文案～';
  }

  return (
    '我已经记录你的问题：「' +
    text +
    '」。\n\n' +
    '你可以试试这样问我：\n' +
    '· 帮我汇总本周班级事务\n' +
    '· 拆解主题班会的执行步骤\n' +
    '· 写一条温和版催办文案\n' +
    '· 查看我还剩哪些待办\n\n' +
    '所有回答均由本地规则生成，不会上传任何信息。'
  );
}

Page({
  data: {
    authorized: false,
    userName: '',
    avatarText: '我',
    inputValue: '',
    sending: false,
    messages: [],
    quickPrompts: [
      { label: '本周事务汇总', prompt: '帮我汇总本周班级事务' },
      { label: '拆解主题班会', prompt: '帮我拆解主题班会的执行步骤' },
      { label: '生成催办文案', prompt: '写一条温和版催办文案' },
      { label: '查看我的待办', prompt: '查看我还剩哪些待办' }
    ]
  },

  onLoad() {
    if (!app.globalData.isLogin) {
      wx.showToast({ title: '请先登录', icon: 'none', duration: 1400 });
      this._denyTimer = setTimeout(() => {
        const pages = getCurrentPages();
        if (pages.length > 1) {
          wx.navigateBack({ delta: 1 });
        } else {
          wx.switchTab({ url: '/pages/index/index' });
        }
      }, 1300);
      return;
    }

    const userName = app.globalData.userName;
    const greeting =
      '你好，' +
      userName +
      '。我是班小助 AI 事务助理。\n' +
      '我可以帮你拆解班级事务、生成通知与催办文案，或汇总当前内存中的待办与统计数据。\n\n' +
      '这是一个完全本地模拟的演示版本，不会调用任何外部大模型。';
    this._msgSeq = 1;
    this.setData({
      authorized: true,
      userName: userName,
      avatarText: userName ? userName.slice(0, 1) : '我',
      messages: [
        {
          id: 'm1',
          role: 'ai',
          text: greeting,
          time: mock.nowTime()
        }
      ]
    });
  },

  onUnload() {
    if (this._replyTimer) clearTimeout(this._replyTimer);
    if (this._denyTimer) clearTimeout(this._denyTimer);
  },

  onInput(e) {
    this.setData({ inputValue: e.detail.value });
  },

  onQuickTap(e) {
    const prompt = e.currentTarget.dataset.prompt;
    this.sendText(prompt);
  },

  sendMessage() {
    const text = (this.data.inputValue || '').trim();
    if (!text) {
      wx.showToast({ title: '先输入想咨询的问题', icon: 'none' });
      return;
    }
    this.setData({ inputValue: '' });
    this.sendText(text);
  },

  sendText(text) {
    if (this.data.sending) {
      wx.showToast({ title: '班小助正在回复', icon: 'none' });
      return;
    }
    const content = (text || '').trim();
    if (!content) return;

    this._msgSeq += 1;
    const userMessage = {
      id: 'm' + this._msgSeq + '-' + Date.now(),
      role: 'user',
      text: content,
      time: mock.nowTime()
    };
    this.setData({
      messages: this.data.messages.concat([userMessage]),
      sending: true
    });
    this.scrollToBottom();

    this._replyTimer = setTimeout(() => {
      this._msgSeq += 1;
      const reply = {
        id: 'm' + this._msgSeq + '-' + Date.now(),
        role: 'ai',
        text: buildReply(content),
        time: mock.nowTime()
      };
      this.setData({
        messages: this.data.messages.concat([reply]),
        sending: false
      });
      this.scrollToBottom();
    }, 760);
  },

  scrollToBottom() {
    setTimeout(() => {
      wx.pageScrollTo({ scrollTop: 999999, duration: 220 });
    }, 80);
  }
});
