const app = getApp();
const mock = require('../../utils/mock.js');

Page({
  data: {
    glassSolid: false,
    isLogin: false,
    isVisitor: true,
    isStudent: false,
    isLeader: false,
    roleText: '访客预览',
    roleSub: '登录后解锁完整班级事务数据',
    dateText: '',
    greeting: '',
    unreadCount: 0,
    publicStats: [],
    kpis: [],
    ringRate: 0,
    ringStyle: '',
    ringLabel: '事务完成率',
    ringCenter: '0%',
    legends: [],
    taskRows: [],
    advice: [],
    timeline: [],
    todoStats: { total: 0, done: 0, pending: 0, percent: 0 },
    taskStats: { total: 0, done: 0, ongoing: 0, pending: 0, percent: 0 },
    activeCount: 0
  },

  onLoad() {
    this.setData({
      dateText: mock.todayText(),
      greeting: mock.greeting()
    });
  },

  onShow() {
    if (app.globalData.userRole !== 'leader') {
      wx.showToast({ title: '仅工作人员可查看驾驶舱', icon: 'none', duration: 1600 });
      this._guardTimer = setTimeout(() => {
        wx.switchTab({ url: '/pages/index/index' });
      }, 500);
      return;
    }
    this.refreshPage();
    this.syncTabBar();
  },

  onUnload() {
    if (this._guardTimer) clearTimeout(this._guardTimer);
    if (this._exportTimer) {
      clearInterval(this._exportTimer);
      this._exportTimer = null;
      wx.hideLoading();
    }
  },

  onPageScroll(e) {
    const solid = e.scrollTop > 18;
    if (solid !== this.data.glassSolid) {
      this.setData({ glassSolid: solid });
      this.updateTabBarGlass(solid);
    }
  },

  updateTabBarGlass(solid) {
    const tabBar = typeof this.getTabBar === 'function' && this.getTabBar();
    if (tabBar) {
      tabBar.setData({ glassSolid: solid });
    }
  },

  refreshPage() {
    const gd = app.globalData;
    const isLogin = gd.isLogin;
    const isLeader = isLogin && gd.userRole === 'leader';
    const isStudent = isLogin && gd.userRole === 'student';
    const isVisitor = !isLogin;
    const taskStats = app.getTaskStats();
    const todoStats = app.getTodoStats();
    const unreadCount = app.getUnreadCount();
    const activeTasks = gd.taskList.filter(function (item) { return item.statusKey !== 'done'; });
    const receiptTarget = activeTasks.reduce(function (sum, item) { return sum + (item.target || 0); }, 0);
    const receiptJoined = activeTasks.reduce(function (sum, item) { return sum + (item.joined || 0); }, 0);
    const receiptRate = receiptTarget ? Math.round((receiptJoined / receiptTarget) * 100) : 0;

    const publicStats = [
      { value: String(taskStats.total), unit: '项', label: '本周公开事务' },
      { value: String(gd.noticeList.length), unit: '条', label: '班级公告' },
      { value: receiptRate + '%', unit: '', label: '公开回执收集' }
    ];

    const baseKpis = [
      {
        icon: '✓',
        tone: 'blue',
        value: taskStats.percent + '%',
        label: '事务完成率',
        hint: taskStats.done + ' / ' + taskStats.total + ' 项已完成'
      },
      {
        icon: '进',
        tone: 'green',
        value: String(activeTasks.length),
        label: '进行中事务',
        hint: '回执收集 ' + receiptRate + '%'
      },
      {
        icon: '待',
        tone: 'orange',
        value: String(todoStats.pending),
        label: '我的待处理',
        hint: '完成率 ' + todoStats.percent + '%'
      },
      {
        icon: '讯',
        tone: 'purple',
        value: String(unreadCount),
        label: '未读消息',
        hint: '回执 / 催办 / 状态变更'
      }
    ];
    const kpis = isStudent ? baseKpis.slice(0, 3) : baseKpis;

    const ringRate = isLeader ? taskStats.percent : todoStats.percent;
    const ringLabel = isLeader ? '事务完成率' : '个人待办完成率';
    const deg = Math.max(ringRate * 3.6, 2);
    const ringStyle =
      'background: conic-gradient(#2f7cf6 0deg, #1cc5a9 ' +
      deg +
      'deg, #e9eff9 ' +
      deg +
      'deg, #e9eff9 360deg);';

    const legends = isLeader
      ? [
          { color: '#2f7cf6', label: '已完成', value: taskStats.done + ' 项' },
          { color: '#1cc5a9', label: '进行中', value: taskStats.ongoing + ' 项' },
          { color: '#dfe6f1', label: '未开始', value: taskStats.pending + ' 项' }
        ]
      : [
          { color: '#2f7cf6', label: '已完成', value: todoStats.done + ' 项' },
          { color: '#1cc5a9', label: '待处理', value: todoStats.pending + ' 项' },
          { color: '#dfe6f1', label: '全部待办', value: todoStats.total + ' 项' }
        ];

    const typeMap = {};
    gd.taskList.forEach(function (task) {
      if (!typeMap[task.type]) {
        typeMap[task.type] = { type: task.type, total: 0, done: 0, ongoing: 0 };
      }
      typeMap[task.type].total += 1;
      if (task.statusKey === 'done') {
        typeMap[task.type].done += 1;
      } else if (task.statusKey === 'ongoing') {
        typeMap[task.type].ongoing += 1;
      }
    });
    const taskRows = Object.keys(typeMap).map(function (key) {
      const row = typeMap[key];
      return {
        type: row.type,
        total: row.total,
        done: row.done,
        ongoing: row.ongoing,
        rate: Math.round((row.done / row.total) * 100)
      };
    });

    const advice = [];
    const laggingTask = activeTasks.find(function (task) { return task.joined < task.target; });
    if (laggingTask) {
      advice.push({
        index: '01',
        title: '优先补齐回执缺口',
        desc:
          '「' +
          laggingTask.title +
          '」还有 ' +
          (laggingTask.target - laggingTask.joined) +
          ' 人未确认，建议使用温和版催办文案。'
      });
    }
    advice.push({
      index: '02',
      title: '关注个人待办完成率',
      desc:
        todoStats.pending > 0
          ? '当前仍有 ' + todoStats.pending + ' 项个人待办未完成，完成后会实时同步至驾驶舱。'
          : '个人待办已全部完成，可以把精力转向班级事务催办与材料归档。'
    });
    advice.push({
      index: '03',
      title: '保持台账同步',
      desc:
        '本周事务完成率 ' +
        taskStats.percent +
        '%，建议在活动结束后当天完成签到表与照片归档，避免材料堆积。'
    });

    const timeline = [];
    gd.noticeList
      .filter(function (item) { return item.isNew; })
      .slice(0, 2)
      .forEach(function (notice) {
        timeline.push({
          title: '班级公告发布',
          desc: notice.title,
          time: notice.time,
          tone: 'blue'
        });
      });
    gd.todoList
      .filter(function (item) { return item.done && item.doneTime; })
      .slice(-2)
      .reverse()
      .forEach(function (todo) {
        timeline.push({
          title: '待办已完成',
          desc: todo.title,
          time: todo.doneTime,
          tone: 'green'
        });
      });
    gd.taskList
      .filter(function (item) { return item.isNew; })
      .slice(0, 2)
      .forEach(function (task) {
        timeline.push({
          title: '新事务已创建',
          desc: task.title,
          time: '刚刚',
          tone: 'orange'
        });
      });

    const staticTimeline = [
      {
        title: '讲座签到事务已完成',
        desc: '心理健康专题讲座回执 36/36，签到表已归档',
        time: '昨天 20:10',
        tone: 'green'
      },
      {
        title: '班级事务周报已生成',
        desc: '第 7 周事务统计与待办完成情况已汇总',
        time: '10月19日 18:05',
        tone: 'blue'
      },
      {
        title: '国家助学金材料收集启动',
        desc: '目标 8 人，当前 6 人已提交材料',
        time: '10月18日 09:00',
        tone: 'orange'
      },
      {
        title: '网络安全主题班会创建',
        desc: '由班长张三发起，截止 10 月 24 日 18:00',
        time: '10月17日 15:20',
        tone: 'blue'
      }
    ];

    const finalTimeline = timeline.concat(staticTimeline).slice(0, 6);
    const keyedTimeline = finalTimeline.map(function (item, index) {
      return Object.assign({ key: 'timeline-' + index }, item);
    });

    let roleText = '访客预览';
    let roleSub = '登录后解锁完整班级事务数据';
    if (isLeader) {
      roleText = '工作人员视角';
      roleSub = '完整数据 · 管理操作已开启';
    } else if (isStudent) {
      roleText = '普通学生视角';
      roleSub = '简化统计 · 管理操作已隐藏';
    }

    this.setData({
      isLogin: isLogin,
      isVisitor: isVisitor,
      isStudent: isStudent,
      isLeader: isLeader,
      roleText: roleText,
      roleSub: roleSub,
      unreadCount: unreadCount,
      publicStats: publicStats,
      kpis: kpis,
      ringRate: ringRate,
      ringStyle: ringStyle,
      ringLabel: ringLabel,
      ringCenter: ringRate + '%',
      legends: legends,
      taskRows: taskRows,
      advice: advice,
      timeline: keyedTimeline,
      todoStats: todoStats,
      taskStats: taskStats,
      activeCount: activeTasks.length
    });
  },

  syncTabBar() {
    const tabBar = typeof this.getTabBar === 'function' && this.getTabBar();
    if (tabBar) {
      tabBar.setData({
        selected: 2,
        unread: app.getUnreadCount(),
        isLeader: true,
        glassSolid: this.data.glassSolid
      });
    }
  },

  onOpTap(e) {
    if (!this.data.isLeader) return;
    const action = e.currentTarget.dataset.action;
    if (action === 'publish') {
      wx.navigateTo({ url: '/pages/publishTask/publishTask' });
      return;
    }
    if (action === 'notice') {
      wx.navigateTo({ url: '/pages/publishTask/publishTask?mode=notice' });
      return;
    }
    if (action === 'export') {
      this.exportLedger();
      return;
    }
    if (action === 'urge') {
      this.sendUrge();
    }
  },

  sendUrge() {
    const lagging = app.globalData.taskList.find(function (task) {
      return task.statusKey !== 'done' && task.joined < task.target;
    });
    const gap = lagging ? lagging.target - lagging.joined : 0;
    const that = this;
    wx.showModal({
      title: '一键催办',
      content: lagging
        ? '将向「' + lagging.title + '」尚未确认的 ' + gap + ' 位同学生成催办提醒，仅写入本地消息列表。'
        : '当前没有回执缺口，是否生成一条常规事务提醒？',
      confirmText: '生成催办',
      cancelText: '取消',
      confirmColor: '#2563eb',
      success(res) {
        if (!res.confirm) return;
        app.addMessage({
          type: 'remind',
          typeText: '催办提醒',
          title: '已生成催办提醒',
          content: lagging
            ? '「' + lagging.title + '」仍有 ' + gap + ' 位同学未确认，请及时跟进。'
            : '本周班级事务整体进度良好，请继续保持台账同步。'
        });
        wx.showToast({ title: '催办提醒已生成', icon: 'none', duration: 1400 });
        that.refreshPage();
        that.syncTabBar();
      }
    });
  },

  exportLedger() {
    if (this._exportTimer) {
      wx.showToast({ title: '正在生成，请稍候', icon: 'none' });
      return;
    }
    const that = this;
    wx.showModal({
      title: '导出班级事务总台账',
      content:
        '文件名：班小助_班级事务总台账.xlsx\n模拟生成进度：0%\n\n演示模拟导出，正式版本生成 Excel 下载。',
      confirmText: '开始生成',
      cancelText: '取消',
      confirmColor: '#2563eb',
      success(res) {
        if (res.confirm) that.startLedgerExport();
      }
    });
  },

  startLedgerExport() {
    let step = 0;
    const steps = [30, 60, 90];
    wx.showLoading({ title: '生成中 0%', mask: true });
    this._exportTimer = setInterval(() => {
      if (step < steps.length) {
        wx.showLoading({ title: '生成中 ' + steps[step] + '%', mask: true });
        step += 1;
        return;
      }
      clearInterval(this._exportTimer);
      this._exportTimer = null;
      wx.hideLoading();
      setTimeout(() => {
        wx.showModal({
          title: '导出完成',
          content:
            '文件名：班小助_班级事务总台账.xlsx\n模拟生成进度：100%\n共汇总 ' +
            app.globalData.taskList.length +
            ' 项班级事务。\n\n演示模拟导出，正式版本生成 Excel 下载。',
          showCancel: false,
          confirmText: '知道了',
          confirmColor: '#2563eb'
        });
      }, 120);
    }, 420);
  }
});
