Page({
  data: {
    openQa: 0,
    metrics: [
      { value: '8', unit: '个', label: '完整页面' },
      { value: '5', unit: '大', label: '业务模块' },
      { value: '3', unit: '类', label: '身份视角' },
      { value: '0', unit: '', label: '后端依赖' }
    ],
    painPoints: [
      {
        no: '01',
        title: '信息散落在群聊里',
        desc: '通知、接龙、回执和材料反复刷屏，重要截止时间容易被淹没。'
      },
      {
        no: '02',
        title: '催办依赖人工追问',
        desc: '谁没回执、谁没交材料需要逐个核对，班干部大量时间耗在重复沟通。'
      },
      {
        no: '03',
        title: '事务结束没有台账',
        desc: '签到表、照片和材料散落各处，复盘与检查时难以快速汇总。'
      }
    ],
    flow: [
      { no: '1', title: '输入事务', desc: '直接用自然语言描述班级要求' },
      { no: '2', title: '风险识别', desc: '本地规则提示隐私、时间与材料风险' },
      { no: '3', title: '智能拆解', desc: '生成可执行步骤、通知与催办文案' },
      { no: '4', title: '执行归档', desc: '模拟执行、同步班级统计、导出台账' }
    ],
    roles: [
      {
        key: 'visitor',
        name: '访客',
        tag: '未登录',
        desc: '底部仅保留首页、消息、我的；可浏览公告，点击我的需登录，没有驾驶舱和班小助入口。'
      },
      {
        key: 'student',
        name: '普通学生',
        tag: '本地登录',
        desc: '底部仅保留首页、消息、我的；可查看个人待办、通知与班级公告，不能发布公告或进入班小助智能体。'
      },
      {
        key: 'leader',
        name: '工作人员',
        tag: '班干部',
        desc: '五栏导航增加驾驶舱与班小助智能体，可使用智能拆解、催办、公告发布、台账导出与完整驾驶舱。'
      }
    ],
    features: [
      { icon: '首', tone: 'blue', title: '首页', desc: '磨砂导航、公告跑马灯、个人待办、任务进度与智能提醒' },
      { icon: '讯', tone: 'green', title: '消息', desc: '通知消息与班级公告双标签，工作人员专属发布入口' },
      { icon: '✦', tone: 'orange', title: '班小助智能体', desc: '直接说要求，自动判断类型、风险与截止时间，生成拆解、通知、催办与可执行方案' },
      { icon: '舱', tone: 'purple', title: '驾驶舱', desc: '工作人员专属 KPI、环形完成率、统计表、AI 建议与时间轴' },
      { icon: '我', tone: 'teal', title: '个人中心', desc: '本地登录身份、设置退出、AI 助理、答辩展示与数据重置' }
    ],
    techs: [
      { icon: 'W', title: '原生框架', desc: 'WXML + WXSS + JS，系统原生导航，无跨端层。' },
      { icon: 'M', title: '内存数据', desc: 'globalData 统一状态；不用云开发、不写本地缓存。' },
      { icon: 'G', title: '动态玻璃 Tab', desc: '滚动驱动通透到磨砂，backdrop-filter blur(16px)，rgba 兜底。' },
      { icon: 'R', title: '规则智能体', desc: '风险识别、自动拆解、通知与催办均使用前端规则。' }
    ],
    demoSteps: [
      '打开小程序：默认访客状态，底部只有首页、消息、我的',
      '点击「我的」：可取消登录；或填入工作人员演示账号',
      '在「我的」中演示身份切换：学生转工作人员需账号 2023010101 与密码 banzhu123',
      '首页勾选待办：完成状态实时同步到班级统计',
      '工作人员点击中间「班小助」：输入班务要求，观察智能体思考与方案生成',
      '创建事务、发布公告并导出模板，最后查看驾驶舱完整数据'
    ],
    highlights: [
      { title: '角色权限可感知', desc: '同一页面在访客、学生、工作人员三种身份下呈现不同内容与操作。' },
      { title: '业务闭环完整', desc: '从发起到通知、执行、催办、统计与导出，形成可演示的完整链路。' },
      { title: '零环境依赖', desc: '直接导入微信开发者工具即可运行，不需要服务器、数据库或 AppID。' },
      { title: '交互原生克制', desc: '无 hover 效果，全部触屏反馈；使用原生 toast、modal 与 loading。' }
    ],
    qaList: [
      {
        q: '为什么坚持使用微信原生小程序？',
        a: '本项目面向班级高频轻量事务，原生小程序包体更小、授权链路更短、微信生态入口更自然；同时可以完整展示 WXML、WXSS、动态自定义 tabBar、原生导航与玻璃动效的实现能力，不依赖任何跨端框架。'
      },
      {
        q: '所有数据保存在哪里？关闭后会怎样？',
        a: '所有登录信息、待办、任务、消息与公告都只保存在 app.js 的 globalData 中，未调用任何本地缓存 API，也未开启云开发。关闭小程序后进程销毁，所有演示数据自然重置。'
      },
      {
        q: '页面里的 AI 能力是真的吗？',
        a: '不是。风险识别、智能拆解、通知生成、催办文案与 AI 事务助理全部由前端关键词和模板规则生成，不调用任何大模型 API。项目中明确标注「本地模拟」，用于验证交互流程与产品思路。'
      },
      {
        q: '权限控制是如何实现的？',
        a: '登录状态统一存储在 globalData。访客和学生使用三栏导航；工作人员端才显示驾驶舱和班小助智能体。自定义 tabBar、publishTask、dashboard 均会再次校验角色，班小助智能体页还会拦截学生与访客。'
      }
    ]
  },

  toggleQa(e) {
    const index = Number(e.currentTarget.dataset.index);
    this.setData({
      openQa: this.data.openQa === index ? -1 : index
    });
  },

  onShareAppMessage() {
    return {
      title: '班小助 · 班级事务智能中枢答辩展示',
      path: '/pages/defense/defense'
    };
  }
});
