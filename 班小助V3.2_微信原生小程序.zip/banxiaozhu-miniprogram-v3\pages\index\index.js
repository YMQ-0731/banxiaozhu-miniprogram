const app = getApp();
const mock = require('../../utils/mock.js');

Page({
  data: {
    glassSolid: false,
    showLogin: false,
    isLogin: false,
    isLeader: false,
    userName: '',
    roleText: '访客模式',
    roleClass: 'visitor',
    dateText: '',
    greeting: '',
    heroSub: '',
    heroStats: [],
    todoList: [],
    todoStats: { total: 0, done: 0, pending: 0, percent: 0 },
    taskPreview: [],
    activeCount: 0,
    taskTotal: 0,
    reminders: [],
    marqueeText: '',
    noticeCount: 0,
    unreadCount: 0
  },

  onLoad() {
    this.setData({
      dateText: mock.todayText(),
      greeting: mock.greeting()
    });
  },

  onShow() {
    this.refreshPage();
    this.syncTabBar();
  },

  onPageScroll(e) {
    const solid = e.scrollTop > 18;
    if (solid !== this.data.glassSolid) {
      this.setData({ glassSolid: solid });
      this.updateTabBarGlass(solid);
    }
  },

  updateTabBarGlass(solid) {
    const tabBar = typeof this.getTabBar === 'function' && this.getTabBar();
    if (tabBar) {
      tabBar.setData({ glassSolid: solid });
    }
  },

  refreshPage() {
    const gd = app.globalData;
    const isLogin = gd.isLogin;
    const isLeader = isLogin && gd.userRole === 'leader';
    const todoStats = app.getTodoStats();
    const taskStats = app.getTaskStats();
    const activeTasks = gd.taskList.filter(function (item) {
      return item.statusKey !== 'done';
    });
    const taskPreview = (activeTasks.length ? activeTasks : gd.taskList).slice(0, 3);
    const unreadCount = app.getUnreadCount();
    const pendingTodos = gd.todoList.filter(function (item) { return !item.done; });
    const noticeList = gd.noticeList;

    let roleText = '访客模式';
    let roleClass = 'visitor';
    if (isLeader) {
      roleText = '工作人员';
      roleClass = 'leader';
    } else if (isLogin) {
      roleText = '普通学生';
      roleClass = 'student';
    }

    let heroSub = '登录后可同步个人待办、接收事务提醒与班级公告。';
    if (isLogin) {
      heroSub =
        '今天有 ' +
        pendingTodos.length +
        ' 项待办、' +
        activeTasks.length +
        ' 项进行中事务，班小助已为你整理好。';
    }

    const heroStats = [
      {
        label: '今日待办',
        value: isLogin ? String(todoStats.pending) : '—',
        unit: isLogin ? '项' : ''
      },
      {
        label: '进行中事务',
        value: String(activeTasks.length),
        unit: '项'
      },
      {
        label: '班级公告',
        value: String(noticeList.length),
        unit: '条'
      }
    ];

    const reminders = [];
    if (!isLogin) {
      reminders.push({
        icon: '公',
        tone: 'blue',
        title: '班级公告已更新，可先浏览',
        desc: '登录后还能看到与个人相关的事务通知'
      });
      reminders.push({
        icon: '事',
        tone: 'green',
        title: '本周共有 ' + taskStats.total + ' 项班级事务',
        desc: '登录后查看完整进度与个人待办'
      });
      reminders.push({
        icon: 'AI',
        tone: 'purple',
        title: '班小助可帮你拆解班级事务',
        desc: '完成登录后，即可体验本地模拟 AI 助理'
      });
    } else {
      if (pendingTodos.length) {
        reminders.push({
          icon: '急',
          tone: 'red',
          title: pendingTodos[0].title,
          desc: '截止 ' + pendingTodos[0].due + '，记得优先处理'
        });
      } else {
        reminders.push({
          icon: '✓',
          tone: 'green',
          title: '个人待办已全部完成',
          desc: isLeader ? '可以到驾驶舱看看班级整体进度' : '今天的个人待办已经全部完成'
        });
      }

      const receiptTask = activeTasks.find(function (item) {
        return item.joined < item.target;
      });
      if (receiptTask) {
        reminders.push({
          icon: '回',
          tone: 'blue',
          title: receiptTask.type + '还有 ' + (receiptTask.target - receiptTask.joined) + ' 人未确认',
          desc: isLeader ? '可到发起事务页生成催办文案' : '工作人员会根据回执情况安排催办'
        });
      } else {
        reminders.push({
          icon: '回',
          tone: 'blue',
          title: '全部事务回执已齐',
          desc: '当前进行中的事务暂无催办缺口'
        });
      }

      reminders.push({
        icon: '讯',
        tone: 'purple',
        title: unreadCount ? '你有 ' + unreadCount + ' 条未读事务消息' : '事务消息已全部读完',
        desc: unreadCount ? '包含任务回执、催办提醒与状态变更' : '新的状态变更会实时出现在消息页'
      });
    }

    const marqueeText =
      noticeList
        .slice(0, 4)
        .map(function (item) { return item.title; })
        .join('　　◆　　') || '暂无班级公告';

    this.setData({
      isLogin: isLogin,
      isLeader: isLeader,
      userName: gd.userName,
      roleText: roleText,
      roleClass: roleClass,
      heroSub: heroSub,
      heroStats: heroStats,
      todoList: gd.todoList,
      todoStats: todoStats,
      taskPreview: taskPreview,
      activeCount: activeTasks.length,
      taskTotal: taskStats.total,
      reminders: reminders,
      marqueeText: marqueeText,
      noticeCount: noticeList.length,
      unreadCount: unreadCount
    });
  },

  syncTabBar() {
    const tabBar = typeof this.getTabBar === 'function' && this.getTabBar();
    if (tabBar) {
      tabBar.setData({
        selected: 0,
        unread: app.getUnreadCount(),
        isLeader: app.globalData.userRole === 'leader',
        glassSolid: this.data.glassSolid
      });
    }
  },

  openLogin() {
    this.setData({ showLogin: true });
  },

  closeLogin() {
    this.setData({ showLogin: false });
  },

  onLoginSuccess() {
    this.setData({ showLogin: false });
    this.refreshPage();
    this.syncTabBar();
  },

  onTodoTap(e) {
    if (!this.data.isLogin) {
      this.openLogin();
      return;
    }
    const id = e.currentTarget.dataset.id;
    const todo = this.data.todoList.find(function (item) { return item.id === id; });
    if (!todo) return;
    if (todo.done) {
      wx.showToast({ title: '该待办已完成', icon: 'none' });
      return;
    }
    const ok = app.completeTodo(id);
    if (ok) {
      this.refreshPage();
      this.syncTabBar();
      wx.showToast({ title: '已完成，数据已同步', icon: 'none', duration: 1500 });
    }
  },

  onAnnouncementTap() {
    app.globalData.messageTab = 'announcement';
    wx.switchTab({ url: '/pages/message/message' });
  },

  goMessage() {
    app.globalData.messageTab = 'notice';
    wx.switchTab({ url: '/pages/message/message' });
  },

  goDashboard() {
    if (!this.data.isLeader) {
      wx.showToast({ title: '仅工作人员可查看驾驶舱', icon: 'none', duration: 1600 });
      return;
    }
    wx.switchTab({ url: '/pages/dashboard/dashboard' });
  },

  goChat() {
    if (!this.data.isLogin) {
      wx.showToast({ title: '请先完成登录', icon: 'none', duration: 1400 });
      this.setData({ showLogin: true });
      return;
    }
    wx.navigateTo({ url: '/pages/chat/chat' });
  },

  onTaskTap(e) {
    const index = Number(e.currentTarget.dataset.index);
    const task = this.data.taskPreview[index];
    if (!task) return;
    const isLeader = this.data.isLeader;
    wx.showModal({
      title: task.type + ' · ' + task.status,
      content:
        task.title +
        '\n负责人：' +
        task.owner +
        '\n截止时间：' +
        task.deadline +
        '\n当前进度：' +
        task.progress +
        '%\n\n' +
        task.desc,
      showCancel: isLeader,
      confirmText: isLeader ? '去驾驶舱' : '知道了',
      cancelText: '关闭',
      success(res) {
        if (isLeader && res.confirm) {
          wx.switchTab({ url: '/pages/dashboard/dashboard' });
        }
      }
    });
  },

  onShareAppMessage() {
    return {
      title: '班小助 · 让班级事务更简单',
      path: '/pages/index/index'
    };
  }
});
