const app = getApp();

Page({
  data: {
    glassSolid: false,
    activeTab: 'notice',
    isLogin: false,
    isLeader: false,
    roleText: '访客模式',
    messages: [],
    notices: [],
    unreadCount: 0,
    expandedId: '',
    showLogin: false
  },

  onShow() {
    const pending = app.globalData.messageTab;
    if (pending === 'notice' || pending === 'announcement') {
      this.setData({ activeTab: pending });
    }
    app.globalData.messageTab = '';
    this.refreshPage();
    this.syncTabBar();
  },

  onPageScroll(e) {
    const solid = e.scrollTop > 18;
    if (solid !== this.data.glassSolid) {
      this.setData({ glassSolid: solid });
      this.updateTabBarGlass(solid);
    }
  },

  updateTabBarGlass(solid) {
    const tabBar = typeof this.getTabBar === 'function' && this.getTabBar();
    if (tabBar) {
      tabBar.setData({ glassSolid: solid });
    }
  },

  refreshPage() {
    const gd = app.globalData;
    const role = gd.userRole;
    const iconMap = {
      receipt: { icon: '回', tone: 'blue' },
      remind: { icon: '催', tone: 'red' },
      status: { icon: '变', tone: 'green' }
    };
    const messages = gd.msgList.map(function (item) {
      const meta = iconMap[item.type] || iconMap.status;
      return Object.assign({}, item, meta);
    });
    const notices = gd.noticeList.map(function (item) {
      return Object.assign({}, item, {
        avatar: item.author ? item.author.slice(0, 1) : '班'
      });
    });

    let roleText = '访客模式';
    if (gd.isLogin && role === 'leader') roleText = '工作人员';
    if (gd.isLogin && role === 'student') roleText = '普通学生';

    this.setData({
      isLogin: gd.isLogin,
      isLeader: gd.isLogin && role === 'leader',
      roleText: roleText,
      messages: messages,
      notices: notices,
      unreadCount: app.getUnreadCount()
    });
  },

  syncTabBar() {
    const tabBar = typeof this.getTabBar === 'function' && this.getTabBar();
    if (tabBar) {
      tabBar.setData({
        selected: 1,
        unread: app.getUnreadCount(),
        isLeader: app.globalData.userRole === 'leader',
        glassSolid: this.data.glassSolid
      });
    }
  },

  switchSubtab(e) {
    const tab = e.currentTarget.dataset.tab;
    if (tab === this.data.activeTab) return;
    this.setData({ activeTab: tab, expandedId: '' });
  },

  openLogin() {
    this.setData({ showLogin: true });
  },

  closeLogin() {
    this.setData({ showLogin: false });
  },

  onLoginSuccess() {
    this.setData({ showLogin: false });
    this.refreshPage();
    this.syncTabBar();
  },

  markAllRead() {
    app.markAllMessagesRead();
    this.refreshPage();
    this.syncTabBar();
    wx.showToast({ title: '已全部标为已读', icon: 'none' });
  },

  onMessageTap(e) {
    if (!this.data.isLogin) {
      this.openLogin();
      return;
    }
    const id = e.currentTarget.dataset.id;
    const msg = this.data.messages.find(function (item) { return item.id === id; });
    if (!msg) return;
    app.markMessageRead(id);
    this.refreshPage();
    this.syncTabBar();
    wx.showModal({
      title: msg.title,
      content: msg.content + '\n\n' + msg.time,
      showCancel: false,
      confirmText: '知道了',
      confirmColor: '#2563eb'
    });
  },

  onNoticeTap(e) {
    const id = e.currentTarget.dataset.id;
    this.setData({
      expandedId: this.data.expandedId === id ? '' : id
    });
  },

  openPublish() {
    if (!app.globalData.isLogin) {
      this.setData({ showLogin: true });
      return;
    }
    if (app.globalData.userRole !== 'leader') {
      wx.showToast({ title: '仅工作人员可发布公告', icon: 'none' });
      return;
    }
    wx.navigateTo({ url: '/pages/publishTask/publishTask?mode=notice' });
  }
});
