const app = getApp();

Page({
  data: {
    glassSolid: false,
    isLogin: false,
    showLogin: false,
    showStaffAuth: false,
    userName: '',
    userId: '',
    userPhone: '',
    avatarText: '',
    roleText: '',
    isLeader: false,
    todoStats: { total: 0, done: 0, pending: 0, percent: 0 },
    taskTotal: 0,
    unreadCount: 0,
    menus: [
      { action: 'setting', icon: '设', tone: 'blue', title: '设置', desc: '账户信息与退出登录' },
      { action: 'chat', icon: 'AI', tone: 'purple', title: 'AI事务助理', desc: '拆解任务、生成通知与汇总' },
      { action: 'defense', icon: '演', tone: 'green', title: '答辩展示', desc: '项目亮点、架构与演示路线' },
      { action: 'reset', icon: '↺', tone: 'orange', title: '重置演示数据', desc: '恢复待办、任务、消息与公告' },
      { action: 'about', icon: 'i', tone: 'gray', title: '关于项目', desc: '版本说明与实现方式' }
    ]
  },

  onShow() {
    this.refreshPage();
    this.syncTabBar();
  },

  onPageScroll(e) {
    const solid = e.scrollTop > 18;
    if (solid !== this.data.glassSolid) {
      this.setData({ glassSolid: solid });
      this.updateTabBarGlass(solid);
    }
  },

  updateTabBarGlass(solid) {
    const tabBar = typeof this.getTabBar === 'function' && this.getTabBar();
    if (tabBar) {
      tabBar.setData({ glassSolid: solid });
    }
  },

  onUnload() {
    if (this._cancelTimer) clearTimeout(this._cancelTimer);
  },

  refreshPage() {
    const gd = app.globalData;
    if (!gd.isLogin) {
      this.setData({
        isLogin: false,
        showLogin: true,
        userName: '',
        userId: '',
        userPhone: '',
        avatarText: '',
        roleText: ''
      });
      return;
    }

    this.setData({
      isLogin: true,
      showLogin: false,
      userName: gd.userName,
      userId: gd.userId,
      userPhone: gd.userPhone,
      avatarText: gd.userName ? gd.userName.slice(0, 1) : '班',
      roleText: app.getRoleText(),
      isLeader: gd.userRole === 'leader',
      todoStats: app.getTodoStats(),
      taskTotal: gd.taskList.length,
      unreadCount: app.getUnreadCount()
    });
  },

  syncTabBar() {
    const tabBar = typeof this.getTabBar === 'function' && this.getTabBar();
    if (tabBar) {
      tabBar.setData({
        selected: 3,
        unread: app.getUnreadCount(),
        isLeader: app.globalData.userRole === 'leader',
        glassSolid: this.data.glassSolid
      });
    }
  },

  onLoginSuccess() {
    this.setData({ showLogin: false });
    this.refreshPage();
    this.syncTabBar();
  },

  onLoginCancel() {
    if (this._cancelTimer) clearTimeout(this._cancelTimer);
    this.setData({ showLogin: false });
    wx.showToast({ title: '已取消登录', icon: 'none', duration: 1000 });
    this._cancelTimer = setTimeout(() => {
      wx.switchTab({ url: '/pages/index/index' });
    }, 180);
  },

  onRoleSwitchTap() {
    if (this.data.isLeader) {
      this.confirmSwitchToStudent();
      return;
    }
    this.setData({ showStaffAuth: true });
  },

  onStaffAuthSuccess() {
    this.setData({ showStaffAuth: false });
    this.refreshPage();
    this.syncTabBar();
  },

  onStaffAuthCancel() {
    this.setData({ showStaffAuth: false });
  },

  confirmSwitchToStudent() {
    const that = this;
    wx.showModal({
      title: '切换至普通学生端',
      content:
        '切换后，底部导航将只保留首页、消息、我的，驾驶舱与班小助入口会隐藏。是否继续？',
      confirmText: '确认切换',
      cancelText: '取消',
      confirmColor: '#2563eb',
      success(res) {
        if (!res.confirm) return;
        app.switchToStudent();
        that.refreshPage();
        that.syncTabBar();
        wx.showToast({ title: '已切换至学生端', icon: 'none', duration: 1500 });
      }
    });
  },

  onMenuTap(e) {
    const action = e.currentTarget.dataset.action;
    if (action === 'setting') {
      wx.navigateTo({ url: '/pages/setting/setting' });
      return;
    }
    if (action === 'chat') {
      wx.navigateTo({ url: '/pages/chat/chat' });
      return;
    }
    if (action === 'defense') {
      wx.navigateTo({ url: '/pages/defense/defense' });
      return;
    }
    if (action === 'reset') {
      this.resetDemoData();
      return;
    }
    if (action === 'about') {
      this.showAbout();
    }
  },

  resetDemoData() {
    const that = this;
    wx.showModal({
      title: '重置演示数据',
      content: '将恢复待办、任务、消息、公告的初始演示数据。当前登录状态会保留。',
      confirmText: '确认重置',
      cancelText: '取消',
      confirmColor: '#d84b4b',
      success(res) {
        if (!res.confirm) return;
        app.resetDemoData();
        that.refreshPage();
        that.syncTabBar();
        wx.showToast({ title: '演示数据已重置', icon: 'none', duration: 1500 });
      }
    });
  },

  showAbout() {
    wx.showModal({
      title: '关于班小助',
      content:
        '班小助 3.2.0\n微信原生小程序 · WXML / WXSS / JS\n\n学生端仅保留首页、消息、我的；工作人员端增加驾驶舱与班小助智能体。\n\n底部导航采用动态水滴磨砂玻璃，滚动时从通透过渡到模糊磨砂。\n\n全部数据保存在本次运行内存中，不开启云开发，不调用真实后端接口，也不调用外部大模型。',
      showCancel: false,
      confirmText: '知道了',
      confirmColor: '#2563eb'
    });
  }
});
