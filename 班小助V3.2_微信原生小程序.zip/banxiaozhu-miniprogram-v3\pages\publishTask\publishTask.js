const app = getApp();
const mock = require('../../utils/mock.js');

const THINKING_STAGES = [
  '理解你的班级事务要求',
  '判断事务类型与截止时间',
  '评估材料、时间与执行风险',
  '生成拆解、通知与催办方案'
];

const BREAKDOWN_MAP = {
  主题班会: [
    { title: '确定班会目标与议程', desc: '明确主题、时长与主讲人，准备案例短片。' },
    { title: '发布通知并收集回执', desc: '生成班级通知，统计参会与请假名单。' },
    { title: '现场签到与材料签署', desc: '设置签到入口，完成后核对未到人员。' },
    { title: '照片归档与台账总结', desc: '整理签到表、承诺书和现场照片。' }
  ],
  团日活动: [
    { title: '确认活动方案与预算', desc: '明确时间、场馆、人数与出行方式。' },
    { title: '发布报名并统计人数', desc: '收集报名信息，完成分组与安全提醒。' },
    { title: '预约场馆与安排出行', desc: '确认预约凭证、车辆与集合点。' },
    { title: '现场组织与材料归档', desc: '签到、拍摄、活动总结和材料留存。' }
  ],
  奖助收集: [
    { title: '发布材料清单与截止时间', desc: '明确申请表、证明材料和命名规范。' },
    { title: '建立收集台账', desc: '按学号核对提交状态，标记缺交项。' },
    { title: '逐项核验材料完整性', desc: '检查签字、盖章与附件是否齐全。' },
    { title: '截止催办与结果公示', desc: '生成催办名单，完成班级内部公示。' }
  ],
  讲座签到: [
    { title: '发布讲座信息与回执', desc: '同步时间地点、主讲人和参会要求。' },
    { title: '统计参会与请假名单', desc: '汇总回执，提前确认座位与设备。' },
    { title: '现场签到与秩序维护', desc: '设置签到入口，记录迟到与缺席。' },
    { title: '签到表归档与总结', desc: '汇总出勤数据，生成讲座台账。' }
  ],
  安全教育: [
    { title: '发布答题入口与要求', desc: '说明截止时间、题量和成绩要求。' },
    { title: '跟踪完成进度', desc: '按学号统计未完成名单，分阶段提醒。' },
    { title: '汇总成绩与错题情况', desc: '形成班级答题统计和薄弱知识点。' },
    { title: '归档安全教育台账', desc: '保存完成截图与成绩表，供后续检查。' }
  ],
  班级事务: [
    { title: '明确目标与交付物', desc: '把事务拆成可执行、可检查的具体结果。' },
    { title: '确定责任人与截止时间', desc: '每个环节指定负责人，设置提醒节点。' },
    { title: '发布通知并收集回执', desc: '同步事务要求，跟踪同学完成情况。' },
    { title: '汇总结果并归档台账', desc: '核对完成名单，形成班级事务记录。' }
  ]
};

function shortTitle(text, fallback) {
  const clean = (text || '').replace(/\s+/g, '');
  if (!clean) return fallback || '本次班级事务';
  return clean.length > 24 ? clean.slice(0, 24) + '…' : clean;
}

function detectType(text) {
  if (/团日|参观|纪念馆/.test(text)) return '团日活动';
  if (/班会/.test(text)) return '主题班会';
  if (/奖助|助学金/.test(text)) return '奖助收集';
  if (/讲座|签到/.test(text)) return '讲座签到';
  if (/反诈|安全教育|答题|安全知识/.test(text)) return '安全教育';
  if (/材料|证明/.test(text)) return '奖助收集';
  if (/安全|演练|出行|场馆/.test(text)) return '安全教育';
  return '班级事务';
}

function inferDeadline(text) {
  const monthDay = text.match(/(\d{1,2})\s*月\s*(\d{1,2})\s*日/);
  if (monthDay) return monthDay[1] + '月' + monthDay[2] + '日';
  const week = text.match(/周[一二三四五六日天]/);
  if (week) return '本' + week[0];
  if (/今天|今日|今晚/.test(text)) return '今天内';
  if (/明天|明日/.test(text)) return '明天内';
  if (/后天/.test(text)) return '后天内';
  if (/下周/.test(text)) return '下周内';
  return '本周内';
}

function inferTone(text) {
  return /紧急|尽快|马上|立即|今天|今晚|必须|严肃|截止|逾期/.test(text)
    ? 'serious'
    : 'gentle';
}

function analyzeRisk(text) {
  const items = [];
  if (/收集|材料|证明|表格|信息/.test(text)) {
    items.push({ level: '注意', text: '涉及材料或个人信息，建议限定收集范围，敏感材料不随意外传。' });
  }
  if (/截止|时间|日期|周[一二三四五六日]/.test(text)) {
    items.push({ level: '建议', text: '已识别时间要求，建议同步设置截止节点与催办提醒。' });
  }
  if (/费用|报销|缴费|预算/.test(text)) {
    items.push({ level: '注意', text: '涉及费用事务，建议保留凭证并在班级内部公示。' });
  }
  if (/安全|反诈|演练|出行|场馆/.test(text)) {
    items.push({ level: '建议', text: '涉及安全或集体出行，建议同步辅导员并完成安全提醒。' });
  }
  if (/签到|参会|回执|出勤/.test(text)) {
    items.push({ level: '建议', text: '建议开启回执或签到统计，实时掌握参与率。' });
  }
  if (text.replace(/\s/g, '').length < 12) {
    items.push({ level: '建议', text: '描述偏短，建议补充任务对象、时间与交付物。' });
  }
  if (!items.length) {
    items.push({ level: '建议', text: '暂未识别到明显风险，建议补充验收标准与责任人。' });
  }

  const high = items.some(function (item) { return item.level === '注意'; });
  return {
    level: high ? '中风险' : '低风险',
    className: high ? 'mid' : 'low',
    items: items.slice(0, 3)
  };
}

function buildUrge(tone, title, deadline) {
  const author = app.globalData.userName || '班干部';
  if (tone === 'serious') {
    return (
      '【严肃催办】@全体成员\n关于「' +
      title +
      '」，目前仍有同学未完成。请于' +
      deadline +
      '前按要求完成并回复确认，逾期将影响班级事务整体进度。\n\n—— ' +
      author
    );
  }
  return (
    '【温和提醒】各位同学好～\n关于「' +
    title +
    '」，目前还有部分同学没有完成。麻烦大家在' +
    deadline +
    '前处理一下，完成后回复「收到」即可，感谢配合！\n\n—— ' +
    author
  );
}

function buildPlan(text) {
  const type = detectType(text);
  const deadline = inferDeadline(text);
  const tone = inferTone(text);
  const risk = analyzeRisk(text);
  const title = shortTitle(text, type);
  const author = app.globalData.userName || '班干部';
  const steps = (BREAKDOWN_MAP[type] || BREAKDOWN_MAP['班级事务']).map(function (item, index) {
    return {
      index: index + 1,
      title: item.title,
      desc: item.desc
    };
  });
  const notificationTitle = '【' + type + '】' + title;
  const notificationContent =
    '各位同学：\n' +
    text +
    '\n\n请于' +
    deadline +
    '前完成，收到请回复「收到」。如有疑问，请及时联系' +
    author +
    '。\n\n—— ' +
    author +
    '\n班小助智能体 · 本地生成';
  const toneLabel = tone === 'serious' ? '严肃催办' : '温和提醒';
  const riskSummary =
    risk.className === 'mid'
      ? '同时识别到需要重点关注的材料或费用风险，我已写入方案。'
      : '暂未发现高风险项，我也补充了执行建议。';

  return {
    id: 'PLAN' + Date.now(),
    sourceText: text,
    title: title,
    type: type,
    deadline: deadline,
    tone: tone,
    toneLabel: toneLabel,
    riskLevel: risk.level,
    riskClass: risk.className,
    riskItems: risk.items,
    steps: steps,
    notificationTitle: notificationTitle,
    notificationContent: notificationContent,
    urgeText: buildUrge(tone, title, deadline),
    summary:
      '我判断这是一项「' +
      type +
      '」事务，建议在「' +
      deadline +
      '」前完成。' +
      riskSummary,
    executed: false
  };
}

function buildAgentReply(plan) {
  return (
    '思考完成。\n' +
    '· 事务类型：' +
    plan.type +
    '\n· 建议截止：' +
    plan.deadline +
    '\n· 风险等级：' +
    plan.riskLevel +
    '\n· 执行拆解：4 个步骤\n· 催办策略：' +
    plan.toneLabel +
    '\n\n方案已生成在下方。你可以直接创建事务、发布公告，或继续告诉我「换成严肃催办」「重新拆解」等调整要求。'
  );
}

function buildWelcome(userName) {
  return (
    '你好，' +
    userName +
    '。我是班小助智能体。\n\n' +
    '不用选择模板，直接把班级要求告诉我。例如：\n' +
    '「本周五组织反诈主题班会，全班参加，收集回执和承诺书。」\n\n' +
    '我会自动判断事务类型、截止时间与风险，拆解执行步骤，并起草通知和催办文案。'
  );
}

Page({
  data: {
    authorized: false,
    userName: '',
    userAvatar: '班',
    mode: '',
    messages: [],
    inputValue: '',
    thinking: false,
    thinkingStages: THINKING_STAGES,
    activeStage: 0,
    latestPlan: null,
    noticeSheet: {
      show: false,
      title: '',
      content: '',
      tag: '班级公告'
    }
  },

  onLoad(options) {
    const gd = app.globalData;
    if (!gd.isLogin) {
      wx.showToast({ title: '请先登录', icon: 'none', duration: 1500 });
      this.denyAccess();
      return;
    }
    if (gd.userRole !== 'leader') {
      wx.showToast({ title: '仅工作人员可使用该功能', icon: 'none', duration: 1800 });
      this.denyAccess();
      return;
    }

    const mode = options && options.mode === 'notice' ? 'notice' : '';
    this._mode = mode;
    this._msgSeq = 1;
    this._lastWelcome = buildWelcome(gd.userName);
    this.setData({
      authorized: true,
      userName: gd.userName,
      userAvatar: gd.userName ? gd.userName.slice(0, 1) : '班',
      mode: mode,
      messages: [
        {
          id: 'agent-welcome',
          role: 'ai',
          text: this._lastWelcome,
          time: mock.nowTime()
        }
      ]
    });
  },

  onReady() {
    if (this._mode === 'notice') {
      this._noticeTimer = setTimeout(() => {
        this.openNoticeComposer(false);
      }, 320);
    }
  },

  onUnload() {
    if (this._denyTimer) clearTimeout(this._denyTimer);
    if (this._agentTimer) {
      clearInterval(this._agentTimer);
      this._agentTimer = null;
    }
    if (this._noticeTimer) clearTimeout(this._noticeTimer);
    if (this._exportTimer) {
      clearInterval(this._exportTimer);
      this._exportTimer = null;
      wx.hideLoading();
    }
  },

  denyAccess() {
    this._denyTimer = setTimeout(() => {
      const pages = getCurrentPages();
      if (pages.length > 1) {
        wx.navigateBack({ delta: 1 });
      } else {
        wx.switchTab({ url: '/pages/index/index' });
      }
    }, 1400);
  },

  stop() {},

  onInput(e) {
    this.setData({ inputValue: e.detail.value });
  },

  sendMessage() {
    const text = (this.data.inputValue || '').trim();
    if (!text) {
      wx.showToast({ title: '先告诉班小助你的要求', icon: 'none' });
      return;
    }
    if (this.data.thinking) {
      wx.showToast({ title: '班小助正在思考', icon: 'none' });
      return;
    }
    this.setData({ inputValue: '' });
    this.startThinking(text);
  },

  startThinking(text) {
    this._msgSeq += 1;
    const userMessage = {
      id: 'user-' + this._msgSeq + '-' + Date.now(),
      role: 'user',
      text: text,
      time: mock.nowTime()
    };
    this.setData(
      {
        messages: this.data.messages.concat([userMessage]),
        thinking: true,
        activeStage: 0
      },
      () => this.scrollToSelector('#thinking-section')
    );

    let stage = 0;
    this._agentTimer = setInterval(() => {
      stage += 1;
      if (stage < THINKING_STAGES.length) {
        this.setData({ activeStage: stage });
        return;
      }
      clearInterval(this._agentTimer);
      this._agentTimer = null;
      this.finishThinking(text);
    }, 360);
  },

  finishThinking(text) {
    const latest = this.data.latestPlan;
    if (this.handleFollowUp(text, latest)) return;

    const compact = text.replace(/\s/g, '');
    if (/^(你好|您好|hi|hello|嗨|在吗)[!！。.%…]*$/i.test(compact)) {
      this.pushAgentMessage(
        '你好，我是班小助智能体。直接说出你要完成的班级事务即可，我会自行判断类型、风险、截止时间，并生成可执行方案。',
        { thinking: false }
      );
      return;
    }

    if (compact.length < 6) {
      this.pushAgentMessage(
        '信息还有点少。能不能再补充一下：这件事的对象是谁、希望什么时候完成、需要产出什么结果？例如“本周五组织反诈主题班会，全班参加并收集回执”。',
        { thinking: false }
      );
      return;
    }

    const plan = buildPlan(text);
    const reply = buildAgentReply(plan);
    this.pushAgentMessage(reply, { thinking: false, latestPlan: plan }, () =>
      this.scrollToSelector('#plan-section')
    );
  },

  handleFollowUp(text, plan) {
    if (!plan) return false;

    if (/(更|换|改|用|要).{0,3}(严肃|正式|强硬)|严肃版|正式版|强硬版/.test(text)) {
      const updated = Object.assign({}, plan, {
        tone: 'serious',
        toneLabel: '严肃催办',
        urgeText: buildUrge('serious', plan.title, plan.deadline)
      });
      this.pushAgentMessage(
        '已根据你的要求，把催办语气调整为严肃版。方案中的其他内容保持不变。',
        { thinking: false, latestPlan: updated },
        () => this.scrollToSelector('#plan-section')
      );
      return true;
    }

    if (/(更|换|改|用|要).{0,3}(温和|委婉|亲切)|温和版|委婉版/.test(text)) {
      const updated = Object.assign({}, plan, {
        tone: 'gentle',
        toneLabel: '温和提醒',
        urgeText: buildUrge('gentle', plan.title, plan.deadline)
      });
      this.pushAgentMessage(
        '已把催办语气调整为温和版，适合日常班级群提醒。',
        { thinking: false, latestPlan: updated },
        () => this.scrollToSelector('#plan-section')
      );
      return true;
    }

    if (/重新拆解|重新规划|重做|换个方案|再拆一次/.test(text)) {
      const newPlan = buildPlan(plan.sourceText);
      this.pushAgentMessage(
        buildAgentReply(newPlan),
        { thinking: false, latestPlan: newPlan },
        () => this.scrollToSelector('#plan-section')
      );
      return true;
    }

    if (/发布公告|发公告|生成公告/.test(text)) {
      this.pushAgentMessage(
        '已根据当前方案打开班级公告发布面板。标题与正文都可以继续编辑，确认后发布。',
        { thinking: false },
        () => this.openNoticeComposer(true)
      );
      return true;
    }

    if (/创建事务|执行方案|一键执行|按方案执行|确认执行|同步驾驶舱/.test(text)) {
      this.setData({ thinking: false });
      this.executePlan();
      return true;
    }

    if (/导出|台账/.test(text)) {
      this.pushAgentMessage(
        '事务台账导出工具在页面下方，支持参会回执、材料收集和班级事务总台账三种模拟导出。',
        { thinking: false },
        () => this.scrollToSelector('#export-section')
      );
      return true;
    }

    if (/清空对话|重新开始|重置智能体/.test(text)) {
      this.pushAgentMessage(
        '可以点击页面上方的「重新开始」清空当前对话和方案，然后重新描述要求。',
        { thinking: false }
      );
      return true;
    }

    return false;
  },

  pushAgentMessage(text, extra, callback) {
    this._msgSeq += 1;
    const message = {
      id: 'agent-' + this._msgSeq + '-' + Date.now(),
      role: 'ai',
      text: text,
      time: mock.nowTime()
    };
    this.setData(
      Object.assign(
        {
          messages: this.data.messages.concat([message])
        },
        extra || {}
      ),
      callback ? function () { callback(); } : undefined
    );
  },

  scrollToSelector(selector) {
    setTimeout(() => {
      wx.pageScrollTo({
        selector: selector,
        offsetTop: -100,
        duration: 280,
        fail() {}
      });
    }, 90);
  },

  scrollToExport() {
    this.scrollToSelector('#export-section');
  },

  executePlan() {
    const plan = this.data.latestPlan;
    if (!plan) {
      wx.showToast({ title: '请先让班小助生成方案', icon: 'none' });
      return;
    }
    if (plan.executed) {
      wx.showToast({ title: '该方案已创建过事务', icon: 'none' });
      return;
    }

    app.addTask({
      title: plan.title,
      type: plan.type,
      deadline: plan.deadline,
      desc: plan.sourceText
    });
    app.addMessage({
      type: 'status',
      typeText: '状态变更',
      title: '智能体已创建事务',
      content: '「' + plan.title + '」已由班小助智能体生成并同步进入驾驶舱。'
    });

    const updated = Object.assign({}, plan, { executed: true });
    this.pushAgentMessage(
      '已创建事务「' +
        plan.title +
        '」，并同步到驾驶舱与消息中心。你还可以继续发布公告或导出事务台账。',
      { latestPlan: updated },
      () => this.scrollToSelector('#plan-section')
    );
    wx.showToast({ title: '事务已创建并同步', icon: 'none', duration: 1500 });
  },

  openPlanNotice() {
    this.openNoticeComposer(true);
  },

  openNoticeTool() {
    this.openNoticeComposer(false);
  },

  openNoticeComposer(usePlan) {
    const plan = this.data.latestPlan;
    let title = '';
    let content = '';
    let tag = '班级公告';
    if (usePlan && plan) {
      title = plan.notificationTitle;
      content = plan.notificationContent;
      tag = plan.type;
    }
    this.setData({
      noticeSheet: {
        show: true,
        title: title,
        content: content,
        tag: tag
      }
    });
  },

  closeNoticeSheet() {
    this.setData({
      noticeSheet: {
        show: false,
        title: '',
        content: '',
        tag: '班级公告'
      }
    });
  },

  onNoticeTitleInput(e) {
    this.setData({ 'noticeSheet.title': e.detail.value });
  },

  onNoticeContentInput(e) {
    this.setData({ 'noticeSheet.content': e.detail.value });
  },

  publishNotice() {
    const title = (this.data.noticeSheet.title || '').trim();
    const content = (this.data.noticeSheet.content || '').trim();
    if (!title) {
      wx.showToast({ title: '请填写公告标题', icon: 'none' });
      return;
    }
    if (!content) {
      wx.showToast({ title: '请填写公告内容', icon: 'none' });
      return;
    }

    app.addNotice({
      title: title,
      content: content,
      author: app.globalData.userName,
      tag: this.data.noticeSheet.tag || '班级公告',
      pinned: false
    });
    this.closeNoticeSheet();
    wx.showToast({ title: '公告发布成功', icon: 'success', duration: 1500 });
    this.pushAgentMessage(
      '公告「' + title + '」已发布，并同步到消息页的班级公告列表。',
      {}
    );
  },

  copyPlanNotice() {
    const plan = this.data.latestPlan;
    if (!plan) return;
    wx.setClipboardData({
      data: plan.notificationTitle + '\n\n' + plan.notificationContent,
      success() {
        wx.showToast({ title: '通知文案已复制', icon: 'none' });
      }
    });
  },

  resetAgent() {
    const that = this;
    wx.showModal({
      title: '重新开始',
      content: '将清空当前对话、智能体方案和输入内容，是否继续？',
      confirmText: '重新开始',
      cancelText: '取消',
      confirmColor: '#2563eb',
      success(res) {
        if (!res.confirm) return;
        if (that._agentTimer) {
          clearInterval(that._agentTimer);
          that._agentTimer = null;
        }
        that._msgSeq = 1;
        const welcome = buildWelcome(that.data.userName);
        that._lastWelcome = welcome;
        that.setData({
          messages: [
            {
              id: 'agent-welcome',
              role: 'ai',
              text: welcome,
              time: mock.nowTime()
            }
          ],
          inputValue: '',
          thinking: false,
          activeStage: 0,
          latestPlan: null,
          noticeSheet: {
            show: false,
            title: '',
            content: '',
            tag: '班级公告'
          }
        });
        wx.showToast({ title: '已重新开始', icon: 'none' });
      }
    });
  },

  handleExport(e) {
    if (this._exportTimer) {
      wx.showToast({ title: '正在生成，请稍候', icon: 'none' });
      return;
    }
    const name = e.currentTarget.dataset.name;
    const file = e.currentTarget.dataset.file;
    const that = this;
    wx.showModal({
      title: '模拟导出',
      content:
        '文件名：' +
        file +
        '\n格式：Excel (.xlsx)\n模拟生成进度：0%\n\n演示模拟导出，正式版本生成 Excel 下载。',
      confirmText: '开始生成',
      cancelText: '取消',
      confirmColor: '#2563eb',
      success(res) {
        if (!res.confirm) return;
        that.startExport(name, file);
      }
    });
  },

  startExport(name, file) {
    let step = 0;
    const steps = [25, 55, 85];
    wx.showLoading({ title: '生成中 0%', mask: true });

    this._exportTimer = setInterval(() => {
      if (step < steps.length) {
        wx.showLoading({ title: '生成中 ' + steps[step] + '%', mask: true });
        step += 1;
        return;
      }

      clearInterval(this._exportTimer);
      this._exportTimer = null;
      wx.hideLoading();
      setTimeout(() => {
        wx.showModal({
          title: '导出完成',
          content:
            '表格：' +
            name +
            '\n文件名：' +
            file +
            '\n模拟生成进度：100%\n\n演示模拟导出，正式版本生成 Excel 下载。',
          showCancel: false,
          confirmText: '知道了',
          confirmColor: '#2563eb'
        });
      }, 120);
    }, 420);
  }
});
