const app = getApp();

Page({
  data: {
    isLogin: false,
    showLogin: false,
    userName: '',
    userId: '',
    userPhone: '',
    roleText: '',
    isLeader: false,
    avatarText: ''
  },

  onShow() {
    this.refreshPage();
  },

  onUnload() {
    if (this._logoutTimer) clearTimeout(this._logoutTimer);
  },

  refreshPage() {
    const gd = app.globalData;
    this.setData({
      isLogin: gd.isLogin,
      userName: gd.userName,
      userId: gd.userId,
      userPhone: gd.userPhone,
      roleText: app.getRoleText(),
      isLeader: gd.userRole === 'leader',
      avatarText: gd.userName ? gd.userName.slice(0, 1) : '访'
    });
  },

  openLogin() {
    this.setData({ showLogin: true });
  },

  closeLogin() {
    this.setData({ showLogin: false });
  },

  onLoginSuccess() {
    this.setData({ showLogin: false });
    this.refreshPage();
  },

  logout() {
    const that = this;
    wx.showModal({
      title: '退出登录',
      content: '确认退出当前账号吗？姓名、学号、手机号与身份信息将被清空，演示数据仍保存在本次运行内存。',
      confirmText: '确认退出',
      cancelText: '取消',
      confirmColor: '#d84b4b',
      success(res) {
        if (!res.confirm) return;
        app.logout();
        wx.showToast({ title: '已退出登录', icon: 'none', duration: 1200 });
        that._logoutTimer = setTimeout(() => {
          wx.switchTab({ url: '/pages/index/index' });
        }, 700);
      }
    });
  }
});
