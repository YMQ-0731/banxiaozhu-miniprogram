/**
 * 本地身份模拟常量
 * 仅用于课堂演示，不涉及真实账号体系。
 */
const STAFF_DEMO = {
  name: '班长张三',
  userId: '2023010101',
  userPhone: '13800138000',
  account: '2023010101',
  password: 'banzhu123'
};

const STUDENT_DEMO = {
  name: '李同学',
  userId: '20230002',
  userPhone: '13900139000'
};

module.exports = {
  STAFF_DEMO: STAFF_DEMO,
  STUDENT_DEMO: STUDENT_DEMO
};
