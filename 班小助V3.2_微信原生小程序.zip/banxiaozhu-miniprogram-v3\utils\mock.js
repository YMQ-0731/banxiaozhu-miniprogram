/**
 * 班小助 · 纯前端演示数据
 * 不调用后端、不写入缓存，小程序进程结束后全部重置。
 */

const WEEK_TEXT = ['日', '一', '二', '三', '四', '五', '六'];

function pad(n) {
  return n < 10 ? '0' + n : '' + n;
}

function todayText() {
  const d = new Date();
  return d.getMonth() + 1 + '月' + d.getDate() + '日 周' + WEEK_TEXT[d.getDay()];
}

function greeting() {
  const h = new Date().getHours();
  if (h < 6) return '夜深了';
  if (h < 9) return '早上好';
  if (h < 12) return '上午好';
  if (h < 14) return '中午好';
  if (h < 18) return '下午好';
  return '晚上好';
}

function nowTime() {
  const d = new Date();
  return '今天 ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
}

function createSeedData() {
  const todoList = [
    {
      id: 'TD2026102101',
      title: '提交国家助学金申请材料',
      desc: '身份证复印件、家庭情况说明、申请表各 1 份',
      taskId: 'T003',
      category: '奖助收集',
      due: '今天 20:00',
      priority: '紧急',
      done: false
    },
    {
      id: 'TD2026102102',
      title: '确认主题班会参会回执',
      desc: '点击进入班会回执页，确认是否到场',
      taskId: 'T001',
      category: '主题班会',
      due: '今天 18:00',
      priority: '重要',
      done: false
    },
    {
      id: 'TD2026102103',
      title: '完成校园安全知识竞答',
      desc: '共 20 题，预计用时 8 分钟',
      taskId: 'T005',
      category: '安全教育',
      due: '10月28日 22:00',
      priority: '普通',
      done: false
    },
    {
      id: 'TD2026102104',
      title: '归档团日活动照片',
      desc: '选取 6 张现场照片上传至班级材料袋',
      taskId: 'T002',
      category: '团日活动',
      due: '明天 12:00',
      priority: '普通',
      done: true
    }
  ];

  const taskList = [
    {
      id: 'T001',
      title: '网络安全与反诈主题班会',
      type: '主题班会',
      owner: '班长张三',
      deadline: '10月24日 18:00',
      status: '进行中',
      statusKey: 'ongoing',
      progress: 72,
      joined: 28,
      target: 36,
      desc: '组织同学观看反诈案例短片，完成签到与承诺书签署。'
    },
    {
      id: 'T002',
      title: '红色场馆参观主题团日',
      type: '团日活动',
      owner: '团支书李然',
      deadline: '10月26日 12:00',
      status: '进行中',
      statusKey: 'ongoing',
      progress: 48,
      joined: 20,
      target: 36,
      desc: '统计报名人数、预约场馆并完成出行分组。'
    },
    {
      id: 'T003',
      title: '国家助学金申请材料收集',
      type: '奖助收集',
      owner: '班长张三',
      deadline: '10月23日 20:00',
      status: '进行中',
      statusKey: 'ongoing',
      progress: 85,
      joined: 6,
      target: 8,
      desc: '核对申请材料完整性，形成班级材料收集台账。'
    },
    {
      id: 'T004',
      title: '心理健康专题讲座签到',
      type: '讲座签到',
      owner: '学习委员陈墨',
      deadline: '10月20日 16:00',
      status: '已完成',
      statusKey: 'done',
      progress: 100,
      joined: 36,
      target: 36,
      desc: '完成现场签到与回执统计。'
    },
    {
      id: 'T005',
      title: '校园安全教育线上答题',
      type: '安全教育',
      owner: '班长张三',
      deadline: '10月28日 22:00',
      status: '已完成',
      statusKey: 'done',
      progress: 100,
      joined: 36,
      target: 36,
      desc: '全班完成安全知识竞答，平均分 92.5。'
    },
    {
      id: 'T006',
      title: '班级事务周报整理',
      type: '班级事务',
      owner: '班长张三',
      deadline: '10月19日 18:00',
      status: '已完成',
      statusKey: 'done',
      progress: 100,
      joined: 5,
      target: 5,
      desc: '汇总本周班级事务数据与待办完成情况。'
    }
  ];

  const msgList = [
    {
      id: 'M001',
      type: 'receipt',
      typeText: '任务回执',
      title: '主题班会回执已更新',
      content: '已有 28/36 位同学提交参会回执，尚有 8 位同学未确认，请及时关注。',
      time: '今天 09:42',
      read: false
    },
    {
      id: 'M002',
      type: 'remind',
      typeText: '催办提醒',
      title: '国家助学金材料即将截止',
      content: '距离材料收集截止还有 2 天，目前仍有 2 位同学未提交材料。',
      time: '今天 08:15',
      read: false
    },
    {
      id: 'M003',
      type: 'status',
      typeText: '状态变更',
      title: '讲座签到事务已完成',
      content: '「心理健康专题讲座签到」已由「进行中」更新为「已完成」，回执 36/36。',
      time: '昨天 20:10',
      read: true
    },
    {
      id: 'M004',
      type: 'remind',
      typeText: '催办提醒',
      title: '安全知识竞答即将截止',
      content: '校园安全教育答题将于 10 月 28 日 22:00 截止，请提醒未完成的同学。',
      time: '昨天 17:30',
      read: false
    },
    {
      id: 'M005',
      type: 'status',
      typeText: '状态变更',
      title: '班级事务周报已生成',
      content: '第 7 周班级事务周报已生成本地预览，可在驾驶舱查看统计摘要。',
      time: '10月19日 18:05',
      read: true
    }
  ];

  const noticeList = [
    {
      id: 'N001',
      title: '关于开展“网络安全与反诈”主题班会的通知',
      content: '各位同学：\n本周五 18:30 将在教学楼 A301 开展网络安全与反诈主题班会。请提前 10 分钟到场，现场完成签到并签署反诈承诺书。如因课程冲突无法参加，请于周四前向班长请假。\n特此通知。',
      time: '今天 10:05',
      author: '班长张三',
      pinned: true,
      tag: '主题班会'
    },
    {
      id: 'N002',
      title: '国家助学金申请材料提交提醒',
      content: '请申请国家助学金的同学于 10 月 23 日 20:00 前，将申请表、家庭情况说明及相关证明材料交至班长处。材料请按「学号+姓名」命名，逾期不再补交。',
      time: '昨天 16:30',
      author: '班长张三',
      pinned: false,
      tag: '奖助收集'
    },
    {
      id: 'N003',
      title: '红色场馆参观主题团日活动报名',
      content: '本月团日活动拟前往市革命历史纪念馆参观，请有意参加的同学于 10 月 22 日 12:00 前完成报名。出行统一包车，集合时间与分组名单将在报名结束后公布。',
      time: '10月19日 18:20',
      author: '团支书李然',
      pinned: false,
      tag: '团日活动'
    },
    {
      id: 'N004',
      title: '校园安全教育线上答题开始啦',
      content: '校园安全教育线上答题已开放，共 20 题，满分 100 分。请全体同学于 10 月 28 日 22:00 前完成，答题结果将计入班级安全教育台账。',
      time: '10月18日 09:10',
      author: '班长张三',
      pinned: false,
      tag: '安全教育'
    },
    {
      id: 'N005',
      title: '关于班级通讯录信息核对的通知',
      content: '为方便后续事务通知，请各位同学核对班级通讯录中的手机号与宿舍信息。如有变更，请于本周内私信班长更新，所有信息仅用于班级内部事务。',
      time: '10月17日 14:40',
      author: '生活委员周宁',
      pinned: false,
      tag: '班级事务'
    }
  ];

  return {
    todoList: todoList,
    taskList: taskList,
    msgList: msgList,
    noticeList: noticeList
  };
}

module.exports = {
  createSeedData: createSeedData,
  todayText: todayText,
  greeting: greeting,
  nowTime: nowTime,
  pad: pad
};
